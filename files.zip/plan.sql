create table if not exists public.plan (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  done boolean not null default false,
  added_by text,
  created_at timestamptz not null default now()
);
alter table public.plan enable row level security;
drop policy if exists "plan_all" on public.plan;
create policy "plan_all" on public.plan for all to anon, authenticated using (true) with check (true);
alter publication supabase_realtime add table public.plan;
